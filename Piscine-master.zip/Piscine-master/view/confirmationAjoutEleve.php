<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Test de Hollande</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
<section>
    <p>Ajout de l'élève effectué</p>
    <a href="PageAdmin.php" class="btn btn-info">Retour</a>
</section>
</body>
</html>