<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Test de Hollande</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <section>
        <form action="ConfirmationAjoutEleve.php" method="post">
            <p>
                <em>Adresse mail : </em>
                <input type="text" name="adresse"/>
            </p>
            <p>
                <em>Promo : </em>
                <input type="text" name="promo" />
            </p>
            <p>
                <input type="submit" value="Ajouter" />
            </p>
        </form>
    </section>
</body>
</html>