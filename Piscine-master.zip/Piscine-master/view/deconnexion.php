<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Test de Hollande</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
<section>
    <p>Déconnexion</p>
    <a href="PageAccueil.php" class="btn btn-info">Accueil</a>
</section>
</body>
</html>